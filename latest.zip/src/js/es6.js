// WOW, ES6!
class ES6 {
	constructor(params) {
		this.params = params;
	}

	getParams() {
		let x = this.params;
		console.log(x);
	}
}

export default ES6;