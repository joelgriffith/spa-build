/*
 *	Index JS
 *	Require all your scripts here and init them!
 *	You should be using the ES6 Import/Export syntax!
 */
import ES6 from './es6.js';

var js = new ES6('cool things are happening!');
js.getParams();