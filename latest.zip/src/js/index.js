/*
 *	Index JS
 *	Require all your scripts here and init them!
 */